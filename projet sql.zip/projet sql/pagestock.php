<?php
require "bdd.php";
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
        $req = $bdd->query("SELECT * FROM products ");
        while ($products = $req->fetch()) {
        ?>
    <p>
        <?php echo $products['productname']; ?>
        <img src="<?php echo $products['urlimage']?>" alt="">
        <a href='edit.php?id=<?php echo $products['id']; ?>'>modifier le stock</a> 
    </p>
    <div>
    <a href='newproduct.php?'>Ajouter un nouveau produit</a></div>
    <?php }?>
</body>
</html>