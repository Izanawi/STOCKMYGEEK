<?php
require "bdd.php";
if (isset($_POST['ajout'])){
    if (
            !empty($_POST['nameproduct']) && 
            !empty($_POST['urlimage']) && 
            !empty($_POST['quantity'])
        )    
    {
        $nameproduct = htmlspecialchars($_POST['nameproduct']);
        $urlimage = htmlspecialchars($_POST['urlimage']);
        $quantity = htmlspecialchars($_POST['quantity']); 

        $req = $bdd->prepare('INSERT INTO products SET productname = "?", urlimage = "?", quantity = ?');
        $req->execute([$nameproduct,$urlimage,$quantity]);

        header("Location: pagestock.php");
    } else {
        echo "Vous n'avez pas rempli tous les champs";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method='POST'>
            <label for='nameproduct'>Nom du produit :</label>
            <input type="text" name="nameproduct" id="nameproduct" >
            <label for='urlimage'>lien de l'image du produit :</label>
            <input type="text" name="urlimage" id="urlimage" >
            <label for='quantity'>Quantité :</label>
            <input type="number" name="quantity" id="quantity"></input>
            <input type="submit" name='ajout'>
        </form>
</body>
</html>