<?php
require "bdd.php";
session_start();
$id = $_GET['id'];
$req = $bdd->query("SELECT * FROM products WHERE id=$id ");
if(isset($_POST["edition"])){
    if(!empty($_POST["stock"])){
        
        $valeurstock = htmlspecialchars($_POST["stock"]);

        $req = $bdd->prepare("UPDATE products SET quantity = ? WHERE id = ?");
        $req->execute([$valeurstock, $id]);
        $logreq = $bdd->prepare("INSERT INTO logs(messages) VALUES (?) ");
        $session =$_SESSION['username'];
        $message = $session."a modifié le stock de".$products["productname"]."à".$product["quantity"]."!";
        $logreq->execute([$message]);
        header("location: pagestock.php");
        
        }
}
while ($products = $req->fetch()) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="POST">
    <div>
        <label for="stock">Stock actuel :<?php echo $products['quantity']; ?></label>
    </div>
        
        <div>
            <p>Nouveau stock :
            <input type="number" name="stock">
            </p>
            
        </div>

        <input type="submit" name="edition">
    </form>
    <?php }?>
</body>
</html>